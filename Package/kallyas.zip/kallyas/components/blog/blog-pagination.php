<?php if(! defined('ABSPATH')){ return; } ?>
<!-- Pagination -->
<div class="pagination--<?php echo $blog_style; ?>">
    <?php zn_pagination(); ?>
</div>
